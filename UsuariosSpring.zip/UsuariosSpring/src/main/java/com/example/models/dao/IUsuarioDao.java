package com.example.models.dao;

import org.springframework.data.repository.CrudRepository;

import com.example.models.entity.Usuario;



public interface IUsuarioDao  extends CrudRepository<Usuario, Long>{

}